import random
n1 = random.randint(0, 9)
print('Bem vindo, adivinhe o numero de 0 a 9, boa sorte.')
number1 = int(input('numero aqui > '))
#invalidas
if number1 > 9:
    print('numero inválido')
#sistemas de numeros
if n1 == 9:
    if number1 == 9:
        print('você adivinhou o numero')
    else:
        print('você perdeu')
if n1 == 8:
    if number1 == 8:
        print('você adivinhou o numero')
    else:
        print('você perdeu')
if n1 == 7:
    if number1 == 7:
        print('você adivinhou o numero')
    else:
        print('você perdeu')
if n1 == 6:
    if number1 == 6:
        print('você adivinhou o numero')
    else:
        print('você perdeu')
if n1 == 5:
    if number1 == 5:
        print('você adivinhou o numero')
    else:
        print('você perdeu')
if n1 == 4:
    if number1 == 4:
        print('você adivinhou o numero')
    else:
        print('você perdeu')
if n1 == 3:
    if number1 == 3:
        print('você adivinhou o numero')
    else:
        print('você perdeu')
if n1 == 2:
    if number1 == 2:
        print('você adivinhou o numero')
    else:
        print('você perdeu')
if n1 == 1:
    if number1 == 1:
        print('você adivinhou o numero')
    else:
        print('você perdeu')
if n1 == 0:
    if number1 == 0:
        print('você adivinhou o numero')
    else:
        print('você perdeu')
